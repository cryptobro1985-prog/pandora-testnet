"""Read-only Bybit WSS check; preserves proxy/TLS and never opens positions."""
import fnmatch
import json
from pathlib import Path
import sys
import time
import websocket

HOST='stream.bybit.com'
SYMBOLS=('INIT','NEAR','BTC','SOL','ETH','LIT','HYPE','ZEC','TAO','GRASS')

def run():
    result={'url':f'wss://{HOST}/v5/public/linear','handshake':False,
            'subscription_confirmed':False,'trades':{s:0 for s in SYMBOLS},'verified':False}
    policy_file=Path('/etc/codex/network-policy.json')
    if policy_file.is_file():
        policy=json.loads(policy_file.read_text()).get('http_network_policy') or {}
        if policy.get('type')=='restricted':
            hosts=[item.get('host','') for item in policy.get('egress_rules',[])]
            if not any(fnmatch.fnmatchcase(HOST,host) for host in hosts):
                result.update(stage='environment_policy',error='stream.bybit.com absent from active restricted allowlist',
                              action='Publish/apply saved environment network configuration, then rerun this diagnostic')
                return result
    ws=None
    try:
        ws=websocket.create_connection(result['url'],timeout=8,enable_multithread=True)
        result.update(handshake=True,stage='subscription');ws.settimeout(2)
        ws.send(json.dumps({'op':'subscribe','req_id':'pandora-network-diagnostic',
                            'args':['publicTrade.'+s+'USDT' for s in SYMBOLS]}))
        deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            try:message=json.loads(ws.recv())
            except websocket.WebSocketTimeoutException:continue
            if message.get('op')=='subscribe' and message.get('req_id')=='pandora-network-diagnostic':
                result['subscription_confirmed']=message.get('success') is True
                if not result['subscription_confirmed']:result['subscription_error']=str(message.get('ret_msg',''))[:200]
            data=message.get('data')
            if isinstance(data,list) and str(message.get('topic','')).startswith('publicTrade.'):
                for row in data:
                    if not isinstance(row,dict):continue
                    symbol=str(row.get('s','')).removesuffix('USDT')
                    if symbol in result['trades']:result['trades'][symbol]+=1
        result['verified']=result['subscription_confirmed'] and all(result['trades'].values())
        result['stage']='receiving_trades' if result['subscription_confirmed'] else 'subscription'
        result['note']='A quiet token with zero trades needs a longer observation; this alone does not prove a subscription failure.'
    except Exception as error:
        result.update(stage='proxy_connect' if isinstance(error,websocket.WebSocketProxyException) else 'connection',
                      error_type=type(error).__name__,error=str(error)[:200])
    finally:
        if ws is not None:ws.close()
    return result

if __name__=='__main__':
    outcome=run();print(json.dumps(outcome,ensure_ascii=False,indent=2));sys.exit(0 if outcome['verified'] else 2)
